#include <iostream>
#include <sstream>
#include <fstream>
#include <stdio.h>
#include <string>

using namespace std;

void create_tex(string, string);
//void delete_tex(string file);
