#include "Latex.h"

Latex::Latex(void)
{
	cadena="";
}

Latex::~Latex(void)
{
}

string  Latex::getCadena(){
	return this->cadena;

}
