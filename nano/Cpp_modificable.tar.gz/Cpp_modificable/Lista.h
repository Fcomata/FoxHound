#include "Latex.h"
#include "Nodo.h"

class Lista:public Latex{

public:
	Lista();
	~Lista();
	bool buscar(int v);
	void insertar(int v);
	void borrar(int v);
	void mostrar();
	void elSiguiente();
	void elPrimero();
	void elUltimo();
	bool elActual();
	int valorActual();
	string getCadena();
	void begin();
	void end();
	string Convertir(int v);
private:
	Nodo* primero;
	Nodo* actual;
	int cant;
};
